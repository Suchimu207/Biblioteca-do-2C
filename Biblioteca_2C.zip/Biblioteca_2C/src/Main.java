public class Main {
    public static void main(String[] args) {
        Interface controle = new Interface();

        controle.Iniciar_menu();

        //===
    }
}